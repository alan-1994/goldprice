Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.default = void 0;

var _default = {
    // 获取银行金列表
    getBankList: {
        path: "gold/gold/listGoldBar"
    }
};

exports.default = _default;