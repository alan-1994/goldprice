var _toast = _interopRequireDefault(require("@vant/weapp/toast/toast"));

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var app = getApp();

Page({
    data: {
        averagePrice: app.globalData.averagePrice,
        buyPrice: "",
        weight: "1.00",
        totalProfit: undefined,
        unitProfit: undefined,
        percent: undefined
    },
    onShareAppMessage: function onShareAppMessage() {// return custom share data when user share.
    },
    onShareTimeline: function onShareTimeline() {// 分享到朋友圈
    },
    onShow: function onShow() {
        this.getTabBar().setData({
            active: "calc"
        });
    },
    onLoad: function onLoad() {},
    /**
   * @Author 不悔
   * @Date 2023-04-01
   * @desrc 格式化输入框数字，只允许数字
   * @export
   * 
  */
    formatValue: function formatValue(value) {
        var tempValue = value;
        tempValue = tempValue.replace(/[^\d.]/g, "");
        //清除“数字”和“.”以外的字符
                tempValue = tempValue.replace(/\.{2,}/g, ".");
        //只保留第一个. 清除多余的
                tempValue = tempValue.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
        if (tempValue.indexOf(".") < 0 && tempValue != "") {
            //以上已经过滤，此处控制的是如果没有小数点，首位不能为类似于 01、02的金额
            tempValue = parseFloat(tempValue);
        }
        return tempValue;
    },
    /**
   * @Author 不悔
   * @Date 2023-04-01
   * @desrc 修改价格
   * @export
   * 
  */
    changePrice: function changePrice(e) {
        var value = e.detail.value;
        this.setData({
            buyPrice: this.formatValue(value)
        });
    },
    /**
   * @Author 不悔
   * @Date 2023-04-01
   * @desrc 修改重量
   * @export
   * 
  */
    changeWeight: function changeWeight(e) {
        var value = e.detail.value;
        this.setData({
            weight: this.formatValue(value)
        });
    },
    /**
   * @Author 不悔
   * @Date 2023-04-01
   * @desrc 计算盈亏
   * @export
   * 
  */
    calc: function calc() {
        var averagePrice = app.globalData.averagePrice;
        if (averagePrice === "暂无数据" || averagePrice === 0) {
            _toast.default.fail("实物黄金价格暂无数据，无法计算！");
            return;
        }
        if (this.data.buyPrice === "") {
            _toast.default.fail("请输入买入价格");
            return;
        }
        if (this.data.buyPrice === 0) {
            _toast.default.fail("买入价格不能为0");
            return;
        }
        if (this.data.weight === "") {
            _toast.default.fail("请输入克重");
            return;
        }
        if (this.data.weight === 0) {
            _toast.default.fail("克重不能为0");
            return;
        }
        var buyPrice = Number(this.data.buyPrice);
        var weight = Number(this.data.weight);
        // 单位盈亏
                var unitProfit = Number((averagePrice - buyPrice).toFixed(2));
        var totalProfit = (unitProfit * weight).toFixed(2);
        var percent = Number((unitProfit / buyPrice * 1e4 / 100).toFixed(2));
        this.setData({
            totalProfit: totalProfit,
            unitProfit: unitProfit,
            percent: percent
        });
    }
});