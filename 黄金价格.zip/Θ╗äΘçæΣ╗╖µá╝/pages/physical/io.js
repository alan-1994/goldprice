Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.default = void 0;

var _default = {
    // 获取实物均价列表
    getPhyscicalList: {
        path: "gold/gold/listPhysicalGold"
    }
};

exports.default = _default;