require("../../@babel/runtime/helpers/Arrayincludes");

var _regenerator = _interopRequireDefault(require("../../@babel/runtime/regenerator"));

var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");

var _io = _interopRequireDefault(require("./io"));

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

var app = getApp();

Page({
    data: {
        // 当前日期
        date: "",
        // 展示的平均价格
        averagePrice: [ "0", ".", "0", "0" ],
        // 实物黄金列表
        physcicalList: []
    },
    onShareAppMessage: function onShareAppMessage() {// return custom share data when user share.
    },
    onShareTimeline: function onShareTimeline() {// 分享到朋友圈
    },
    onShow: function onShow() {
        this.getTabBar().setData({
            active: "physical"
        });
    },
    onLoad: function onLoad() {
        // this.setData({
        //   date: daysjs(new Date()).format('YYYY-MM-DD')
        // })
        this.getPhyscicalList();
    },
    /**
   * @Author 不悔
   * @Date 2023-04-01
   * @desrc 获取实物均价列表
   * @export
   * 
  */
    getPhyscicalList: function() {
        var _getPhyscicalList = _asyncToGenerator2(/* */ _regenerator.default.mark(function _callee() {
            var brandSort, res, total, count, firstItem, physcicalList, averagePrice, item;
            return _regenerator.default.wrap(function _callee$(_context) {
                while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        _context.prev = 0;
                        brandSort = [ "周大福", "老凤祥", "周六福", "周大生", "中国黄金", "周生生", "老庙黄金" ];
                        _context.next = 4;
                        return app.request(_io.default.getPhyscicalList);

                      case 4:
                        _context.t0 = _context.sent;
                        if (_context.t0) {
                            _context.next = 7;
                            break;
                        }
                        _context.t0 = [];

                      case 7:
                        res = _context.t0;
                        total = 0;
                        count = 0;
                        // 筛选出排序中有的数据,并按顺序排列
                                                firstItem = [];
                        res.map(function(item, index) {
                            var _ref = item || {}, price = _ref.price, brand = _ref.brand, percent = _ref.percent;
                            item.percent = (percent * 100).toFixed(2);
                            if (price || price === 0) {
                                total += price;
                                count += 1;
                            }
                            var sortItemIndex = brandSort.findIndex(function(cItem) {
                                return cItem === brand;
                            });
                            if (sortItemIndex > -1) {
                                firstItem[sortItemIndex] = item;
                            }
                        });
                        physcicalList = firstItem.filter(function(item) {
                            return item;
                        }).concat(res.filter(function(item) {
                            return !brandSort.includes(item.brand);
                        }));
                        averagePrice = "暂无数据";
                        if (total !== 0) {
                            averagePrice = parseFloat(total / count).toFixed(2);
                            app.globalData.averagePrice = averagePrice;
                        }
                        item = physcicalList[0];
                        this.setData({
                            date: item === null || item === void 0 ? void 0 : item.date,
                            physcicalList: physcicalList,
                            averagePrice: averagePrice.split("")
                        });
                        _context.next = 22;
                        break;

                      case 19:
                        _context.prev = 19;
                        _context.t1 = _context["catch"](0);
                        console.log(_context.t1);

                      case 22:
                      case "end":
                        return _context.stop();
                    }
                }
            }, _callee, this, [ [ 0, 19 ] ]);
        }));
        function getPhyscicalList() {
            return _getPhyscicalList.apply(this, arguments);
        }
        return getPhyscicalList;
    }()
});