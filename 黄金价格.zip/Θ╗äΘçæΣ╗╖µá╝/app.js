var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = require("@babel/runtime/helpers/asyncToGenerator");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

// app.ts
App({
    globalData: {
        averagePrice: 0,
        isCloudRequest: true,
        prefix: "http://192.168.113.24:8082/"
    },
    onLaunch: function onLaunch() {
        // 展示本地存储能力
        var logs = wx.getStorageSync("logs") || [];
        logs.unshift(Date.now());
        wx.setStorageSync("logs", logs);
        // 登录
                wx.login({
            success: function success(res) {
                console.log(res.code);
                // 发送 res.code 到后台换取 openId, sessionKey, unionId
                        }
        });
    },
    request: function request(option, data) {
        var number = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
        var requestIsCloudRequest = option.isCloudRequest;
        var isCloudRequest = requestIsCloudRequest === undefined ? this.globalData.isCloudRequest : requestIsCloudRequest;
        if (isCloudRequest) {
            return this.cloudRequest(option, data, number);
        } else {
            return this.wxReuqest(option, data);
        }
    },
    cloudRequest: function() {
        var _cloudRequest = _asyncToGenerator2(/* */ _regenerator.default.mark(function _callee(option, data) {
            var number, that, path, _option$method, method, res, _ref, code, resData, msg, error, _args = arguments;
            return _regenerator.default.wrap(function _callee$(_context) {
                while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        number = _args.length > 2 && _args[2] !== undefined ? _args[2] : 0;
                        that = this;
                        if (!(that.cloud == null)) {
                            _context.next = 6;
                            break;
                        }
                        that.cloud = new wx.cloud.Cloud({
                            traceUser: true,
                            env: "prod-9gvnszodd9fe1221",
                            resourceEnv: "prod-9gvnszodd9fe1221"
                        });
                        _context.next = 6;
                        return that.cloud.init();

                      case 6:
                        _context.prev = 6;
                        path = option.path, _option$method = option.method, method = _option$method === void 0 ? "GET" : _option$method;
                        _context.next = 10;
                        return that.cloud.callContainer({
                            path: path,
                            // 填入业务自定义路径和参数，根目录，就是 / 
                            method: method,
                            // 按照自己的业务开发，选择对应的方法
                            header: {
                                "X-WX-SERVICE": "gold"
                            },
                            data: data
                        });

                      case 10:
                        res = _context.sent;
                        _ref = (res === null || res === void 0 ? void 0 : res.data) || {}, code = _ref.code, 
                        resData = _ref.data, msg = _ref.msg;
                        if (!(code === 0)) {
                            _context.next = 16;
                            break;
                        }
                        return _context.abrupt("return", resData);

                      case 16:
                        wx.showToast({
                            title: msg || "接口调用失败",
                            icon: "error",
                            duration: 3e3
                        });
                        console.log("微信云托管调用结果".concat(msg));

                      case 18:
                        _context.next = 28;
                        break;

                      case 20:
                        _context.prev = 20;
                        _context.t0 = _context["catch"](6);
                        error = _context.t0.toString();
                        // 如果错误信息为未初始化，则等待300ms再次尝试，因为 init 过程是异步的
                                                if (!(error.indexOf("Cloud API isn't enabled") != -1 && number < 3)) {
                            _context.next = 27;
                            break;
                        }
                        return _context.abrupt("return", new Promise(function(resolve) {
                            setTimeout(function() {
                                resolve(that.request(option, number + 1));
                            }, 300);
                        }));

                      case 27:
                        throw new Error("微信云托管调用失败".concat(error));

                      case 28:
                      case "end":
                        return _context.stop();
                    }
                }
            }, _callee, this, [ [ 6, 20 ] ]);
        }));
        function cloudRequest(_x, _x2) {
            return _cloudRequest.apply(this, arguments);
        }
        return cloudRequest;
    }(),
    wxReuqest: function() {
        var _wxReuqest = _asyncToGenerator2(/* */ _regenerator.default.mark(function _callee2(option, data) {
            var isMock, url, method, prefix;
            return _regenerator.default.wrap(function _callee2$(_context2) {
                while (1) {
                    switch (_context2.prev = _context2.next) {
                      case 0:
                        isMock = true;
                        url = option.path, method = option.method;
                        prefix = isMock ? "http://127.0.0.1:4523/mock/2228389/" : this.globalData.prefix;
                        return _context2.abrupt("return", new Promise(function(reslove, reject) {
                            wx.request({
                                url: "".concat(prefix).concat(url),
                                //仅为示例，并非真实的接口地址
                                data: data,
                                method: method,
                                header: {
                                    "content-type": "application/json"
                                },
                                success: function success(res) {
                                    var _res$data = res.data, code = _res$data.code, data = _res$data.data, _res$data$apifoxError = _res$data.apifoxError, apifoxError = _res$data$apifoxError === void 0 ? {} : _res$data$apifoxError;
                                    if (code === 0) {
                                        return reslove(data);
                                    } else {
                                        wx.showToast({
                                            title: apifoxError.message || "接口调用失败",
                                            icon: "error",
                                            duration: 3e3
                                        });
                                        console.log("微信云托管调用结果".concat(apifoxError.message));
                                    }
                                },
                                fail: function fail(err) {
                                    reject(err);
                                }
                            });
                        }));

                      case 4:
                      case "end":
                        return _context2.stop();
                    }
                }
            }, _callee2, this);
        }));
        function wxReuqest(_x3, _x4) {
            return _wxReuqest.apply(this, arguments);
        }
        return wxReuqest;
    }()
});