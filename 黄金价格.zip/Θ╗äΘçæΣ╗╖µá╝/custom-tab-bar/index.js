Component({
    data: {
        active: "gold",
        tabList: [ {
            name: "physical",
            pagePath: "/pages/physical/index",
            icon: "physical",
            text: "实物黄金"
        }, {
            name: "bank",
            pagePath: "/pages/bank/index",
            icon: "bank",
            text: "银行黄金"
        }, {
            name: "calc",
            pagePath: "/pages/calc/index",
            icon: "calc",
            text: "盈亏计算"
        } ]
    },
    methods: {
        onChange: function onChange(event) {
            var detail = event.detail;
            var activeTabItem = this.data.tabList.filter(function(item) {
                return item.name === detail;
            })[0] || {};
            var pagePath = activeTabItem.pagePath;
            wx.switchTab({
                url: pagePath
            });
            this.setData({
                active: detail
            });
        }
    }
});